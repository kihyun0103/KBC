﻿<?php
include "session.php";
include "db.php";
 
 $title=$_POST['title'];
 $content=$_POST['content'];
 $no=$_POST['no'];

 
 $sql = "insert into board (title, content, date)";
 $sql = $sql. "values('$title','$content',now())";
$res = $dbConnect->query($sql);
if($res === false){
    echo mysqli_error($dbConnect);
}
else{
 echo("<script>location.replace('list.php');</script>");
}
?>
