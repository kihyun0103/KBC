﻿<?php

   include "session.php";
   include "db.php";


   if(!$_SESSION['ses_userid']){
?>
    <script>
        alert('로그인 후 이용 가능합니다.');
      history.back();
    </script>
<?php
  }


  if(!$_POST['pw']){
?>
    <script>
      alert("비밀번호를 입력해 주세요.");
      history.back();
    </script>
<?php
    exit;
  }
  if(!$_POST['pw2']){
?>
    <script>
      alert("변경하실 비밀번호를 입력해 주세요.");
      history.back();
    </script>
<?php
    exit;
  }
  if($_POST['pw2'] != $_POST['pw3']){
?>
    <script>
      alert("비밀번호를 확인해 주세요.");
      history.back();
    </script>
<?php
    exit;
  }
  if(!$_POST['name']){
?>
    <script>
      alert("변경하실 닉네임을 입력해 주세요.");
      history.back();
    </script>
<?php
    exit;
  }
  if(!$_POST['email']){
?>
    <script>
      alert("변경하실 이메일을 입력해 주세요.");
      history.back();
    </script>
<?php
    exit;
  }



  $sql = "select * from account_info where id = '$_SESSION[ses_userid]'";
  $result = $dbConnect->query($sql);
  $row = $result->fetch_array();
  

  if(md5($_POST['pw']) == $row['pwd']){
    $sql = "update account_info set pwd = md5('$_POST[pw2]'), name = '$_POST[name]', email = '$_POST[email]' where id = '$_SESSION[ses_userid]'";	
    $result = $dbConnect->query($sql);
    
    $sql = "select * from account_info where id = '$_SESSION[ses_userid]'";	
    $result = $dbConnect->query($sql);
    $row = $result->fetch_array();


?>	
   
<script>
      alert("회원정보가 수정 되었습니다.");
      location.href="loginmain.php";
    </script>
<?php
}else{
?>
    <script>
      alert("비밀번호가 일치하지않습니다.");
      history.back();
    </script>
<?php
    exit;
  }
?>	

