﻿<?php

   include "session.php";
   include "db.php";
ini_set('display_errors', '0');
   if($_SESSION['ses_userid'] != "admin"){
?>
    <script>
        alert('공지사항은 관리자만 작성할 수 있습니다.');
      history.back();
    </script>
<?php
}else{ echo("<script>location.replace('write.php');</script>");
?>
<?php
    exit;
  }
?>	
