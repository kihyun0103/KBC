﻿<?php
    include "session.php";
    include "db.php";


//조회수 업데이트
$no = $_POST['no'];
$sql = "update board set hit=hit+1 where board_num=$no";
$result = $dbConnect->query($sql);

//글 정보 가져오기
$inforsql = "select board_num,admin,title,date,hit,content from 
                       board where board_num=$no";
$result = $dbConnect->query($inforsql);
$row = $result->fetch_assoc();


?>
<html>
	<head>
<title>공지사항</title>
<style>
<!--
td { font-size : 9pt; }
A:link { font : 9pt; color black; text-decoration : none; font-family : 굴림; 
         font-size : 9pt; }
A:visitied { text-decoration : none; color : black; font-size : 9pt; }
A:hover { text-decoration : underline; color : black; font-size : 9pt }
-->
</style>

<body topmargin=0 leftmargin=0 text=#464646>
<center>
<BR>
		<title>KBC</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,700,500,900' rel='stylesheet' type='text/css'>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-panels.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel-noscript.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-desktop.css" />
		</noscript>
<style type="text/css">
#content{
width:800px;

}

</style>
	</head>
	<body class="homepage">

	<!-- Header -->
		<div id="header">
			<div id="nav-wrapper"> 
				<!-- Nav -->
				<nav id="nav">
					<ul>
						<li class="active"><a href="index.php">메인페이지</a></li>
                                                                        <li><a href="introduce.php">게임소개</a></li>
						<li><a href="list.php">공지사항</a></li>
						<li><a href="racingrecord.php">주행기록</a></li>
						<li><a href="racingvideo.php">주행영상</a></li>
                                                                        <li><a href="memberinformation.php">회원정보 수정</a></li>
					</ul>
				</nav>
                                    <div class="container"> 

				<!-- Logo -->
				<div id="logo">
					<h1><a href="#">게임소개</a></h1>
                                    </div>
		</div>

	<!-- Featured -->
		<div id="featured">
			<div id="content" class="container">
				<section>
					<table width=800 border=0 cellpadding=2 cellspacing=1 bgcolor=#777777>
<tr>
    <td height=20 colspan=4 align=center bgcolor=#999999>
        <font color=green size=4px><B><?= $row['title'] ?></B></font>
    </td>
</tr>
<tr>
    <td width=50 height=20 align=center bgcolor=#EEEEEE>글쓴이</td><td width=240 bgcolor=white><?=$row['admin']?></td>
    <td width=50 height=20 align=center bgcolor=#EEEEEE>글번호</td><td class="no" width=240 bgcolor=white><?= $row['board_num'] ?></td>
<tr>
    <td width=50 height=20 align=center bgcolor=#EEEEEE>날&nbsp;&nbsp;&nbsp;짜</td><td class="date"  width=240 bgcolor=white><?= $row['date']?></td>
    <td width=50 height=20 align=center bgcolor=#EEEEEE>조회수</td><td width=240 bgcolor=white><?=$row['hit']?></td>
</tr>

<tr>
    <td bgcolor=white colspan=4>
        <font color=black size=4px>
            <pre><?=$row['content']?></pre>
        </font>
    </td>
</tr>

<!-- 기타 버튼들 -->
<tr>
    <td colspan=4 bgcolor=#999999>
        <table width=100%>
            <tr>
                <td width=200 align=left height=10 style="text-align:center">
                    <a href=list.php?><font color=white size=4px>[목록보기]</font></a>
                </td>

<!-- 기타 버튼 끝 -->




         </table>
</b></font>
</td>
</tr>
</table>
<?php
mysqli_close($dbConnect);
?>
</center>
</body>
				</section>
			</div>
		</div>
	</body>
</html>