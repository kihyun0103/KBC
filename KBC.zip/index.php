﻿<?php
    include "session.php";
    include "db.php";

?>
<html>
	<head>
		<title>KBC</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,700,500,900' rel='stylesheet' type='text/css'>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-panels.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel-noscript.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-desktop.css" />
		</noscript>
	</head>
	<body class="homepage">

	<!-- Header -->
		<div id="header">
			<div id="nav-wrapper"> 
				<!-- Nav -->
				<nav id="nav">
					<ul>
						<li class="active"><a href="index.php">메인페이지</a></li>
                                                                        <li><a href="introduce.php">게임소개</a></li>
						<li><a href="list.php">공지사항</a></li>
						<li><a href="racingrecord.php">주행기록</a></li>
						<li><a href="racingvideo.php">주행영상</a></li>
                                                                        <li><a href="memberinformation.php">회원정보 수정</a></li>
					</ul>
				</nav>
			</div>
			<div class="container"> 
				
				<!-- Logo -->
				<div id="logo">
					<h1><a href="#">VR Racing</a></h1>
					<span class="tag">By KBC</span>
				</div>
				
			</div>
		</div>

	<!-- Featured -->
		<div id="featured">
			<div class="container">
				<header>
					<h2>Welcome to VR Racing by KBC</h2>
				</header>
<div id="wrap" style="text-align: center; margin: ()auto;">
    <div id="container">
        <form name="singIn" action="./signIn.php" method="post" onsubmit="return checkSubmit()">
            <div class="line">
                <p>LOGIN</p>
                <div class="inputArea">
                    <input type="text" value="아이디" name="memberId" class="memberId" style="height:50px; width:400px; />
                </div>
            </div>
            <div class="line">
                <div class="inputArea">
                    <input type="password" value="비밀번호" name="memberPw" class="memberPw" style="height:50px; width:400px; />
                </div>
            </div>
            <div class="line">
            </div>
            <div class="line">
                <input type="submit" value="로그인" style="height:70px; width:400px; background-color:green; font-size:45px; border:2px white solid; color:#ffffff;" class="submit" />
            </div>
            <div class="line">
                 <input type="button" value="회원가입" style="height:70px; width:400px; background-color:green; font-size:45px; border:2px white solid; color:#ffffff;" onclick=location.href='signup.php'>
            </div>
</form>
				<hr />


	</body>
</html>