﻿<html>
<head>
		<title>KBC</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,700,500,900' rel='stylesheet' type='text/css'>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-panels.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel-noscript.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-desktop.css" />
		</noscript>
<script type="text/javascript" src="logincheck.js"></script>
</head>
<body>
<!-- Header -->
		<div id="header">
			<div id="nav-wrapper"> 
				<!-- Nav -->
				<nav id="nav">
					<ul>
						<li class="active"><a href="loginmain.php">메인페이지</a></li>
                                                                        <li><a href="loginintroduce.php">게임소개</a></li>
						<li><a href="loginlist.php">공지사항</a></li>
						<li><a href="racingrecord.php">주행기록</a></li>
						<li><a href="racingvideo.php">주행영상</a></li>
                                                                        <li><a href="memberinformation.php">회원정보 수정</a></li>
					</ul>
				</nav>
                                    </div>
                                    <div class="container"> 

				<!-- Logo -->
				<div id="logo">
					<h1><a href="#">VR Racing</a></h1>
					<span class="tag">By KBC</span>
                                    </div>
                                    </div>
		</div>

	<!-- Featured -->
		<div id="featured">
			<div id="content" class="container">
				<section>
					<header>
<?php
    include "session.php";
    include "db.php";
echo "<font size=7>".$_SESSION['ses_userid'].'님 안녕하세요.';
?>
</div>
<input type="button" value="로그아웃" style="height:100px; width:311px; background-color:green; font-size:45px; border:2px white solid; color:#ffffff;" onclick=location.href='logout.php'> 
					</header>

				</section>
			</div>
		

<div class="line">    
    </div>
</div>
</body>
</html>