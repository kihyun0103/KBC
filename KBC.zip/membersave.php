﻿<?php
include "db.php";
 
 $id=$_POST['id'];
 $password=md5($_POST['pwd']);
 $password2=$_POST['pwd2'];
 $name=$_POST['name'];
 $address=$_POST['addr'];
 $sex=$_POST['sex'];
 $birthDay=$_POST['birthDay'];
 $email=$_POST['email'];
 
 $sql = "insert into account_info (id, pwd, name, addr, sex, birthDay, email)";
 $sql = $sql. "values('$id','$password','$name','$address','$sex','$birthDay','$email')";
$res = $dbConnect->query($sql);
if($res === false){
    echo mysqli_error($dbConnect);
}
else
{
 echo("<script>location.replace('index.php');</script>");
}
?>