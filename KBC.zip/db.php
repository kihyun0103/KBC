﻿<?php
  $host = 'localhost';
  $user = 'root';
  $passWord = '111111';
  $dbName = 'kbc';
 
  $dbConnect = new mysqli($host,$user,$passWord,$dbName);

 function mq($sql)
	{
		global $db;
		return $db->query($sql);
	}

?>