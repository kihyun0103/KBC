﻿	<html>
	<head>
		<title>KBC</title>
		<meta http-equiv="content-type" content="text/html; charset=utf-8" />
		<meta name="description" content="" />
		<meta name="keywords" content="" />
		<link href='http://fonts.googleapis.com/css?family=Roboto:400,100,300,700,500,900' rel='stylesheet' type='text/css'>
		<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
		<script src="js/skel.min.js"></script>
		<script src="js/skel-panels.min.js"></script>
		<script src="js/init.js"></script>
		<noscript>
			<link rel="stylesheet" href="css/skel-noscript.css" />
			<link rel="stylesheet" href="css/style.css" />
			<link rel="stylesheet" href="css/style-desktop.css" />
		</noscript>
	</head>
	<body class="homepage">

	<!-- Header -->
		<div id="header">
			<div id="nav-wrapper"> 
				<!-- Nav -->
				<nav id="nav">
					<ul>
						<li class="active"><a href="index.php">메인페이지</a></li>
                                                                        <li><a href="introduce.php">게임소개</a></li>
						<li><a href="list.php">공지사항</a></li>
						<li><a href="racingrecord.php">주행기록</a></li>
						<li><a href="racingvideo.php">주행영상</a></li>
                                                                        <li><a href="memberinformation.php">회원정보 수정</a></li>
					</ul>
				</nav>

                                    <div class="container"> 

				<!-- Logo -->
				<div id="logo">
					<h1><a href="#">회원가입</a></h1>

                                    </div>
		</div>

	<!-- Featured -->
		<div id="featured">
			<div id="content" class="container">
				<section>
					<header>
						<body>
<style type="text/css">

p{color:black; font-size:30px;}
</style>
<div id="wrap" style="text-align: center; margin: ()auto;">
<form name="join" method="post" action="memberSave.php">
<table style="border: 2px solid black; margin:auto;>
  <tr>
   <td>아이디</td>
   <td><input type="text" size="30" name="id"></td>
  </tr>
  <tr>
   <td>아이디</td>
   <td><input type="text" size="30" name="id"></td>
  </tr>
  <tr>
   <td>비밀번호</td>
   <td><input type="password" size="30" name="pwd"></td>
  </tr>
  <tr>
   <td>비밀번호 확인</td>
   <td><input type="password" size="30" name="pwd2"></td>
  </tr>
  <tr>
  <tr>
   <td>이름</td>
   <td><input type="text" size="30" maxlength="10" name="name"></td>
  </tr>
  <tr>
   <td>주소</td>
   <td><input type="text" size="30" name="addr"></td>
  </tr>
  <tr>
   <td>성별</td>
   <td><input type="text" size="30" maxlength="2" name="sex"></td>
  </tr>
  <tr>
   <td>생년월일</td>
   <td><input type="text" value="ex)19940103" size="30" maxlength="8" name="birthDay"></td>
  </tr>
  <tr>
   <td>이메일</td>
   <td><input type="text" size="30" name="email"></td>
  </tr>
 </table>
 <input type=submit value="가입하기" style="height:65px; width:200px; background-color:green; font-size:37px; border:2px white solid; color:#ffffff;">
</form>
</div>
</body>
					</header>						

				</section>
			</div>
		</div>
	</body>
</html>