﻿<?php
    include "session.php";
    include "db.php";
 
    $memberId = $_POST['memberId'];
    $memberPw = md5($memberPw = $_POST['memberPw']);
 
 
    $sql = "SELECT * FROM account_info WHERE id = '{$memberId}' AND pwd = '{$memberPw}'";
    $res = $dbConnect->query($sql);
 
 
        $row = $res->fetch_array(MYSQLI_ASSOC);
 
 
        if ($row != null) {
            $_SESSION['ses_userid'] = $row['id'];
            echo("<script>location.replace('loginmain.php');</script>");
        }

        if($row == null){
?>
           <script>
           alert('아이디와 비밀번호를 확인해주세요.');
           history.back();
           </script>
<?php
        }

?>