﻿<?php
    include "session.php";
    unset($_SESSION['ses_userid']);
 echo("<script>location.replace('index.php');</script>");
?>